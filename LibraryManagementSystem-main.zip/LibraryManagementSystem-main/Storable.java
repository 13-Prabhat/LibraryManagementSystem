package src.oop;

public interface Storable {
    void validate() throws Exception;
}
