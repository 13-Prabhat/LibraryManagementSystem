package src.oop;

public interface LibraryActions {

    void addBook(String title);

    void removeBook(String title);

    void searchBook(String title);
}

