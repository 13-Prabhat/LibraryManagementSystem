package src.main; 

import src.ui.MainUI;

public class App {
    public static void main(String[] args) {
        new MainUI(); 
    }
}

